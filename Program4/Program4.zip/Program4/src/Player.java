/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author tiennguyen
 */
public class Player {
    private int fighter;

    public void setFighter(int fighter) {
        this.fighter = fighter;
    }

    public void setRanger(int ranger) {
        this.ranger = ranger;
    }

    public void setMage(int mage) {
        this.mage = mage;
    }

    public void setCleric(int cleric) {
        this.cleric = cleric;
    }

    public void setRouge(int rouge) {
        this.rouge = rouge;
    }

    public void setBard(int bard) {
        this.bard = bard;
    }

    public void setStrength(int strength) {
        this.strength = strength;
    }

    public void setConstitution(int constitution) {
        this.constitution = constitution;
    }

    public void setIntelligence(int intelligence) {
        this.intelligence = intelligence;
    }

    public void setWisdom(int wisdom) {
        this.wisdom = wisdom;
    }

    public void setDexterity(int dexterity) {
        this.dexterity = dexterity;
    }

    public void setCharisma(int charisma) {
        this.charisma = charisma;
    }
    private int ranger;
    private int mage;
    private int cleric;
    private int rouge;
    private int bard;
    private int strength;
    private int constitution;
    private int intelligence;
    private int wisdom;
    private int dexterity;

    public int getFighter() {
        return fighter;
    }

    public int getRanger() {
        return ranger;
    }

    public int getMage() {
        return mage;
    }

    public int getCleric() {
        return cleric;
    }

    public int getRouge() {
        return rouge;
    }

    public int getBard() {
        return bard;
    }

    public int getStrength() {
        return strength;
    }

    public int getConstitution() {
        return constitution;
    }

    public int getIntelligence() {
        return intelligence;
    }

    public int getWisdom() {
        return wisdom;
    }

    public int getDexterity() {
        return dexterity;
    }

    public int getCharisma() {
        return charisma;
    }
    private int charisma;               
}
    

